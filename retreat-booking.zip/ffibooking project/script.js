// 🔥 CONFIG — replace with your Firebase project keys
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

const bookingForm = document.getElementById("bookingForm");
const datePicker = document.getElementById("datePicker");
const roomType = document.getElementById("roomType");
const roomStatus = document.getElementById("roomStatus");
const readGuidelines = document.getElementById("readGuidelines");

// Admin elements
const adminPassInput = document.getElementById("adminPass");
const adminPanel = document.getElementById("adminPanel");
const adminTable = document.querySelector("#adminTable tbody");
const availabilityTable = document.querySelector("#availabilityTable tbody");

// Load availability for today + next 30 days (create docs if not exist)
const today = new Date();
for (let i = 0; i < 30; i++) {
  const d = new Date();
  d.setDate(today.getDate() + i);
  const formatted = d.toISOString().split('T')[0];
  db.collection("availability").doc(formatted).get()
    .then(doc => {
      if (!doc.exists) {
        db.collection("availability").doc(formatted).set({ single: 2, double: 2 });
      }
    });
}

// Show availability when date changes
datePicker.addEventListener("change", () => {
  const date = datePicker.value;
  if (!date) return;
  db.collection("availability").doc(date).get()
    .then(doc => {
      if (!doc.exists) {
        roomStatus.innerHTML = "No availability";
        return;
      }
      const data = doc.data();
      roomStatus.innerHTML = `Single: ${data.single} | Double: ${data.double}`;
      if (data.single === 0 && data.double === 0) {
        alert("Date fully booked");
        datePicker.value = "";
        roomStatus.innerHTML = "";
      }
    });
});

// Booking submission
bookingForm.addEventListener("submit", (e) => {
  e.preventDefault();

  if (!readGuidelines.checked) {
    alert("You must confirm that you have read the guidelines");
    return;
  }

  const selectedDate = datePicker.value;
  const selectedRoom = roomType.value;

  if (!selectedDate || !selectedRoom) { alert("Select date & room"); return; }

  const bookingData = {
    fullName: document.getElementById("fullName").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value,
    retreatType: document.querySelector("input[name='retreatType']:checked").value,
    groupName: document.getElementById("groupName").value || "",
    groupCount: document.getElementById("groupCount").value || "-",
    date: selectedDate,
    roomType: selectedRoom,
    duration: document.getElementById("duration").value,
    specialRequests: document.getElementById("specialRequests").value,
    needAccommodation: document.getElementById("needAccommodation").value,
    needMeals: document.getElementById("needMeals").value,
    medicalNeeds: document.getElementById("medicalNeeds").value,
    timestamp: firebase.firestore.Timestamp.now()
  };

  // Check availability & submit
  const availRef = db.collection("availability").doc(selectedDate);
  availRef.get().then(doc => {
    if (!doc.exists) { alert("No availability"); return; }
    const data = doc.data();
    if (data[selectedRoom] <= 0) { alert("No rooms left"); return; }

    db.collection("bookings").add(bookingData).then(() => {
      availRef.update({ [selectedRoom]: firebase.firestore.FieldValue.increment(-1) });
      alert("Booking successful!");
      bookingForm.reset();
      readGuidelines.checked = false;
      roomStatus.innerHTML = "";
      loadAdminTables();
    }).catch(err => { console.error(err); alert("Error!"); });
  });
});

// Admin login
function unlockAdmin() {
  if (adminPassInput.value === "admin123") {
    adminPanel.classList.remove("hidden");
    loadAdminTables();
  } else {
    alert("Wrong password");
  }
}

// Load admin tables
function loadAdminTables() {
  // Live bookings
  db.collection("bookings").orderBy("timestamp","desc").onSnapshot(snapshot => {
    adminTable.innerHTML = "";
    snapshot.forEach(doc => {
      const b = doc.data();
      adminTable.innerHTML += `<tr>
        <td>${b.fullName}</td><td>${b.phone}</td><td>${b.email}</td>
        <td>${b.date}</td><td>${b.roomType}</td><td>${b.retreatType}</td>
        <td>${b.groupCount || "-"}</td>
      </tr>`;
    });
  });

  // Room availability
  db.collection("availability").onSnapshot(snapshot => {
    availabilityTable.innerHTML = "";
    snapshot.forEach(doc => {
      const a = doc.data();
      availabilityTable.innerHTML += `<tr>
        <td>${doc.id}</td><td>${a.single}</td><td>${a.double}</td>
      </tr>`;
    });
  });
}

// Export bookings to CSV
function exportBookings() {
  db.collection("bookings").get().then(snapshot => {
    let csv = "Full Name,Phone,Email,Date,Room,Retreat Type,Participants\n";
    snapshot.forEach(doc => {
      const b = doc.data();
      csv += `"${b.fullName}","${b.phone}","${b.email}","${b.date}","${b.roomType}","${b.retreatType}","${b.groupCount || "-"}"\n`;
    });
    const blob = new Blob([csv], {type: "text/csv"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "bookings.csv"; a.click();
    URL.revokeObjectURL(url);
  });
}